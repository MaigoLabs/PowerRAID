# PowerRAID Mechanical Enclosure & 3D Printed Parts

This archive contains all mechanical design files for the PowerRAID acrylic enclosure and 3D printed parts.

## 1. 3D Printed Parts (`3d_printed_parts/`)
STEP models for standard PLA/PETG FDM 3D printing (as described in manuscript Section 4.2):
- `PLA Standoff Nut.step` (3× required): Hexagonal M3 standoff nut with self-tapping bore.
- `PLA Standoff Nut Special.step` (1× required): Relieved hexagonal nut for clearance near high-current bus.
- `Stick Cap.step` (4× required): Retaining endcap for upper crossbar beams.
- `Stick Cap B.step` (4× required): Retaining endcap for lower crossbar beams.

## 2. Laser-Cut Acrylic Panels (`laser_cut/`)
Production-ready 2D DXF, SVG, and true-scale PDF vector files organized by sheet thickness:
- `1.5mm_Extruded_Acrylic/`: Bottom Padding cushion plate (`Bottom Padding.*`) and nested sheet (`1.5mm_Full_Sheet_Nested.*`).
- `3.0mm_Cast_Acrylic/`: Front connector panel, Side 1, Side 2, Middle 1, Middle 2 dividers, and nested sheet (`3.0mm_Full_Sheet_Nested.*`).
- `4.5mm_Cast_Acrylic/`: Baseplate (Bottom), Top lid, 4 clamping crossbars (`Stick B1`, `Stick B2`, `Stick T1`, `Stick T2`), and nested sheet (`4.5mm_Full_Sheet_Nested.*`).

Each vector file uses the two-layer cutting standard:
- Layer `CUT_INSIDE` (Red `#FF0000`): Internal cutouts, bolt holes, slots (cut 1st).
- Layer `CUT_OUTSIDE` (Black `#000000`): Outside panel perimeter (cut 2nd).

## 3. Complete CAD Models (`3d_models/`)
- `Enclosure.step`: Complete 3D mechanical assembly.
- `Liteon PS-2122-3H.step`: 3D mechanical model of the server power supply module reconstructed from physical caliper measurements.
- `3d_models/panels/`: Individual STEP models of all acrylic panels.

## 4. Automation Scripts (`scripts/`)
- `scripts/prepare_laser_cut_panels.py`: Automated pipeline that extracts 2D planar cutting contours with OpenCASCADE/FreeCAD, optimizes sheet nesting via Sparrow (`sparrow`), and outputs production DXF, SVG, and PDF sheets.

Online Onshape CAD: https://cad.onshape.com/documents/740d641897b2359339c9fbf7

Licensed under CERN-OHL-P-2.0.
