#!/usr/bin/env python3
"""
prepare_laser_cut_panels.py - Automated 2D laser-cut profile extraction and nesting pipeline.

Pipeline:
1. Ingests 3D panel models from 3D/Enclosure.zip (or 3D/Enclosure.step).
2. Categorizes panels by material thickness (1.5mm, 3.0mm, 4.5mm).
3. Projects watertight 2D planar cutting contours with OpenCASCADE:
   - Layer CUT_INSIDE (Red, #FF0000): Internal cutouts, bolt holes, slots (cut 1st).
   - Layer CUT_OUTSIDE (Black, #000000): Outside panel perimeter (cut 2nd).
   - Exports individual .dxf, .svg, and 1:1 scale .pdf files.
4. Uses Sparrow (https://github.com/JeroenGar/sparrow) to nest each material group
   to minimize bounding strip area with configurable part clearance (2.0 mm).
5. Exports production-ready nested sheets (*_Full_Sheet_Nested.dxf, .svg, and .pdf).
"""

import sys
import os
import shutil
import zipfile
import json
import subprocess
from pathlib import Path

# Add FreeCAD paths
sys.path.extend(['/usr/lib/freecad/lib', '/usr/lib/freecad/Mod', '/usr/lib/freecad/Ext'])
import FreeCAD
import Part
import TechDraw
import importDXF

REPO_ROOT = Path(__file__).resolve().parent.parent

# Support running both inside Enclosure.zip and from the development repository
if (REPO_ROOT / "laser_cut").is_dir():
    OUTPUT_DIR = REPO_ROOT / "laser_cut"
    PANELS_DIR = REPO_ROOT / "3d_models" / "panels"
    ZIP_PATH = REPO_ROOT / "3d_models" / "Enclosure.step"
    BUNDLE_ZIP = REPO_ROOT / "PowerRAID_Laser_Cut_Files.zip"
else:
    OUTPUT_DIR = REPO_ROOT / "3D" / "laser_cut"
    PANELS_DIR = REPO_ROOT / "3D" / "3d_models" / "panels"
    ZIP_PATH = REPO_ROOT / "3D" / "Enclosure.zip"
    BUNDLE_ZIP = REPO_ROOT / "3D" / "PowerRAID_Laser_Cut_Files.zip"

# Material specifications and sheet stock limits at Waterloo ESMS machine shop
MATERIAL_SPECS = {
    1.5: {
        'folder': '1.5mm_Extruded_Acrylic',
        'sheet_w': 355.6,  # 14.0 in
        'sheet_h': 279.4,  # 11.0 in
        'strip_h': 260.0,
        'label': '1.5 mm Extruded Acrylic (14x11 in)',
    },
    3.0: {
        'folder': '3.0mm_Cast_Acrylic',
        'sheet_w': 533.4,  # 21.0 in
        'sheet_h': 279.4,  # 11.0 in
        'strip_h': 245.0,  # ESMS safe margin limit
        'label': '3.0 mm Cast Acrylic (21x11 in)',
    },
    4.5: {
        'folder': '4.5mm_Cast_Acrylic',
        'sheet_w': 660.4,  # 26.0 in
        'sheet_h': 406.4,  # 16.0 in
        'strip_h': 390.0,  # ESMS safe margin limit
        'label': '4.5 mm Cast Acrylic (26x16 in)',
    },
}

SKIP_KEYWORDS = ['PSU', 'Nut', 'Cap', 'Mock_PCB', 'Tolerance']
SPACING_MM = 2.0  # Kerf / clearance between parts


def export_panel_vectors(sh, dxf_path, svg_path, pdf_path, margin=5.0):
    """Export single panel with layer separation (CUT_INSIDE Red, CUT_OUTSIDE Black) and >=2mm margin on each side."""
    outer = sh.OuterWire
    inner = [w for w in sh.Wires if not w.isSame(outer)]

    # 1. DXF with named layers
    doc = FreeCAD.newDocument('ExportDoc')
    if inner:
        obj_in = doc.addObject('Part::Feature', 'CUT_INSIDE')
        obj_in.Shape = Part.makeCompound(inner)
    obj_out = doc.addObject('Part::Feature', 'CUT_OUTSIDE')
    obj_out.Shape = outer
    doc.recompute()
    importDXF.export(doc.Objects, str(dxf_path))
    FreeCAD.closeDocument('ExportDoc')

    # 2. SVG with standard RGB laser colors and >=2mm margin on each side
    s_out = {'stroke': '#000000', 'stroke-width': '0.05mm', 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'fill': 'none'}
    s_in = {'stroke': '#FF0000', 'stroke-width': '0.05mm', 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'fill': 'none'}

    bb = sh.BoundBox
    shift = FreeCAD.Placement(FreeCAD.Vector(margin - bb.XMin, margin - bb.YMin, 0), FreeCAD.Rotation())
    outer_shifted = outer.copy()
    outer_shifted.Placement = shift * outer_shifted.Placement
    inner_shifted = [w.copy() for w in inner]
    for w in inner_shifted:
        w.Placement = shift * w.Placement

    svg_out = TechDraw.projectToSVG(outer_shifted, FreeCAD.Vector(0, 0, 1), 'Visible', 0.01, s_out, s_out, s_out)
    svg_in = TechDraw.projectToSVG(Part.makeCompound(inner_shifted), FreeCAD.Vector(0, 0, 1), 'Visible', 0.01, s_in, s_in, s_in) if inner_shifted else ""

    svg_w = bb.XLength + 2 * margin
    svg_h = bb.YLength + 2 * margin
    svg_content = f'''<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg"
     width="{svg_w:.3f}mm" height="{svg_h:.3f}mm"
     viewBox="0 {-svg_h:.3f} {svg_w:.3f} {svg_h:.3f}">
  <g id="CUT_INSIDE">
{svg_in}
  </g>
  <g id="CUT_OUTSIDE">
{svg_out}
  </g>
</svg>'''
    with open(svg_path, 'w', encoding='utf-8') as f:
        f.write(svg_content)

    # 3. 1:1 Scale PDF via rsvg-convert
    subprocess.run(['rsvg-convert', '-f', 'pdf', str(svg_path), '-o', str(pdf_path)], check=True)


def export_nested_sheet(placed_items, target_folder, thickness_str, sheet_w_limit, sheet_h_limit, margin=5.0):
    """Export placed nested panels to *_Full_Sheet_Nested.dxf/.svg/.pdf with >=2mm gap on each side."""
    all_inner = []
    all_outer = []
    nested_shapes = []

    # 1. Pairwise geometric overlap and minimum separation validation
    n_items = len(placed_items)
    for i in range(n_items):
        for j in range(i + 1, n_items):
            n1, sh1 = placed_items[i]
            n2, sh2 = placed_items[j]
            inter = sh1.common(sh2)
            if inter.Area > 0.001:
                raise ValueError(f"Geometric overlap detected between '{n1}' and '{n2}': {inter.Area:.3f} mm²!")
            dist, _, _ = sh1.distToShape(sh2)
            if dist < 2.0:
                raise ValueError(f"Clearance violation between '{n1}' and '{n2}': {dist:.3f} mm < 2.0 mm!")

    for name, sh in placed_items:
        nested_shapes.append(sh)
        outer = sh.OuterWire
        inner = [w for w in sh.Wires if not w.isSame(outer)]
        all_outer.append(outer)
        all_inner.extend(inner)

    compound = Part.makeCompound(nested_shapes)
    c_bb = compound.BoundBox

    dx = margin - c_bb.XMin
    dy = margin - c_bb.YMin
    shift = FreeCAD.Placement(FreeCAD.Vector(dx, dy, 0), FreeCAD.Rotation())

    all_outer_shifted = [w.copy() for w in all_outer]
    for w in all_outer_shifted:
        w.Placement = shift * w.Placement

    all_inner_shifted = [w.copy() for w in all_inner]
    for w in all_inner_shifted:
        w.Placement = shift * w.Placement

    total_bb = Part.makeCompound(all_outer_shifted).BoundBox
    footprint_w = total_bb.XMax + margin
    footprint_h = total_bb.YMax + margin

    # 2. Validate margin on each side of the nested sheet
    left_gap = total_bb.XMin
    bottom_gap = total_bb.YMin
    right_gap = footprint_w - total_bb.XMax
    top_gap = footprint_h - total_bb.YMax
    min_edge_gap = min(left_gap, bottom_gap, right_gap, top_gap)
    if min_edge_gap < 2.0:
        raise ValueError(f"Sheet edge clearance violation: min edge gap {min_edge_gap:.2f} mm < 2.0 mm!")

    base_name = f"{thickness_str}_Full_Sheet_Nested"
    dxf_path = target_folder / f"{base_name}.dxf"
    svg_path = target_folder / f"{base_name}.svg"
    pdf_path = target_folder / f"{base_name}.pdf"

    # 1. DXF export with layers
    doc = FreeCAD.newDocument('NestedDoc')
    if all_inner_shifted:
        obj_in = doc.addObject('Part::Feature', 'CUT_INSIDE')
        obj_in.Shape = Part.makeCompound(all_inner_shifted)
    obj_out = doc.addObject('Part::Feature', 'CUT_OUTSIDE')
    obj_out.Shape = Part.makeCompound(all_outer_shifted)
    doc.recompute()
    importDXF.export(doc.Objects, str(dxf_path))
    FreeCAD.closeDocument('NestedDoc')

    # 2. SVG export with exact mm dimensions
    s_out = {'stroke': '#000000', 'stroke-width': '0.05mm', 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'fill': 'none'}
    s_in = {'stroke': '#FF0000', 'stroke-width': '0.05mm', 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'fill': 'none'}

    svg_out = TechDraw.projectToSVG(Part.makeCompound(all_outer_shifted), FreeCAD.Vector(0, 0, 1), 'Visible', 0.01, s_out, s_out, s_out)
    svg_in = TechDraw.projectToSVG(Part.makeCompound(all_inner_shifted), FreeCAD.Vector(0, 0, 1), 'Visible', 0.01, s_in, s_in, s_in) if all_inner_shifted else ""

    svg_content = f'''<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg"
     width="{footprint_w:.2f}mm" height="{footprint_h:.2f}mm"
     viewBox="0 {-footprint_h:.2f} {footprint_w:.2f} {footprint_h:.2f}">
  <g id="CUT_INSIDE">
{svg_in}
  </g>
  <g id="CUT_OUTSIDE">
{svg_out}
  </g>
</svg>'''
    with open(svg_path, 'w', encoding='utf-8') as f:
        f.write(svg_content)

    # 3. 1:1 Scale PDF via rsvg-convert
    subprocess.run(['rsvg-convert', '-f', 'pdf', str(svg_path), '-o', str(pdf_path)], check=True)

    status = "FITS" if (footprint_w <= sheet_w_limit and footprint_h <= sheet_h_limit) else "EXCEEDS"
    return footprint_w, footprint_h, status


def get_ordered_wire_polygon(wire, deflection=0.2):
    """
    Discretizes a FreeCAD Wire into a closed, continuous 2D polygon with points ordered head-to-tail.
    FreeCAD wire.OrderedEdges can have reversed edge orientations; chaining ensures no jump discontinuities.
    """
    edges = list(wire.OrderedEdges if hasattr(wire, 'OrderedEdges') else wire.Edges)
    if not edges:
        return []

    edge_pts = []
    for edge in edges:
        pts = edge.discretize(Deflection=deflection)
        if len(pts) >= 2:
            edge_pts.append([(pt.x, pt.y) for pt in pts])

    if not edge_pts:
        return []

    # Chain edges head-to-tail
    remaining = edge_pts[1:]
    current_chain = list(edge_pts[0])

    while remaining:
        curr_end = current_chain[-1]
        best_idx = 0
        best_dist = float('inf')
        reverse_best = False

        for i, pts in enumerate(remaining):
            d_start = (pts[0][0] - curr_end[0])**2 + (pts[0][1] - curr_end[1])**2
            d_end = (pts[-1][0] - curr_end[0])**2 + (pts[-1][1] - curr_end[1])**2
            if d_start < best_dist:
                best_dist = d_start
                best_idx = i
                reverse_best = False
            if d_end < best_dist:
                best_dist = d_end
                best_idx = i
                reverse_best = True

        next_edge = remaining.pop(best_idx)
        if reverse_best:
            next_edge = next_edge[::-1]

        current_chain.extend(next_edge[1:])

    # Deduplicate closing point if identical to starting point
    if len(current_chain) > 1:
        d_close = (current_chain[-1][0] - current_chain[0][0])**2 + (current_chain[-1][1] - current_chain[0][1])**2
        if d_close < 1e-4:
            current_chain.pop()

    return [[round(x, 3), round(y, 3)] for x, y in current_chain]


def run_sparrow_nest(items_dict, strip_h, tmp_run_dir):
    """Execute sparrow to solve 2D strip packing problem."""
    sparrow_items = []
    for idx, (name, sh) in items_dict.items():
        poly = get_ordered_wire_polygon(sh.OuterWire)

        sparrow_items.append({
            'id': idx,
            'demand': 1,
            'orientation': {'rotation': {'mode': 'discrete', 'angles': [0.0, 90.0, 180.0, 270.0]}},
            'shape': {
                'type': 'simple_polygon',
                'data': poly
            }
        })

    instance = {
        'name': 'nest_task',
        'strip_height': strip_h,
        'min_item_separation': SPACING_MM,
        'items': sparrow_items
    }

    input_json = tmp_run_dir / "sparrow_input.json"
    with open(input_json, 'w') as f:
        json.dump(instance, f, indent=2)

    # Run sparrow with 3s budget and early termination
    cmd = ['sparrow', '-i', str(input_json), '-t', '3', '-x']
    subprocess.run(cmd, cwd=str(tmp_run_dir), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)

    solution_json = tmp_run_dir / "output" / "final_nest_task.json"
    with open(solution_json, 'r') as f:
        sol = json.load(f)

    placed_items = []
    for item in sol['solution']['layout']['placed_items']:
        idx = item['item_id']
        name, base_sh = items_dict[idx]
        rot_deg = item['transformation']['rotation']  # in degrees
        tx, ty = item['transformation']['translation']

        sh_placed = base_sh.copy()
        t_rot = FreeCAD.Rotation(FreeCAD.Vector(0, 0, 1), rot_deg)
        t_trans = FreeCAD.Vector(tx, ty, 0)
        sh_placed.Placement = FreeCAD.Placement(t_trans, t_rot) * sh_placed.Placement
        placed_items.append((name, sh_placed))

    return placed_items


def main():
    tmp_dir = Path("/tmp/agy_nest_work")
    if tmp_dir.exists():
        shutil.rmtree(tmp_dir)
    tmp_dir.mkdir(parents=True, exist_ok=True)

    panels_by_thickness = {1.5: {}, 3.0: {}, 4.5: {}}

    try:
        if PANELS_DIR.exists() and list(PANELS_DIR.glob("*.step")):
            print(f"Ingesting panels from directory: {PANELS_DIR}")
            step_paths = [p for p in sorted(PANELS_DIR.glob("*.step")) if not any(k in p.name for k in SKIP_KEYWORDS)]
            for p in step_paths:
                clean_name = p.stem.replace('Enclosure - ', '').strip()
                shape = Part.Shape()
                shape.read(str(p))

                bb = shape.BoundBox
                dims = sorted([bb.XLength, bb.YLength, bb.ZLength])
                t_raw = dims[0]
                t = min(MATERIAL_SPECS.keys(), key=lambda k: abs(k - t_raw))

                planar_faces = [f for f in shape.Faces if isinstance(f.Surface, Part.Plane)]
                if not planar_faces:
                    continue
                planar_faces.sort(key=lambda f: f.Area, reverse=True)
                face = planar_faces[0]

                norm = face.normalAt(0, 0)
                rot = FreeCAD.Rotation(norm, FreeCAD.Vector(0, 0, 1))
                sh = face.copy()
                sh.Placement = FreeCAD.Placement(FreeCAD.Vector(0, 0, 0), rot)
                f_bb = sh.BoundBox
                sh.Placement = FreeCAD.Placement(FreeCAD.Vector(-f_bb.XMin, -f_bb.YMin, 0), FreeCAD.Rotation()) * sh.Placement

                idx = len(panels_by_thickness[t])
                panels_by_thickness[t][idx] = (clean_name, sh)

        elif ZIP_PATH.exists():
            print(f"Ingesting panels from: {ZIP_PATH.name}")
            with zipfile.ZipFile(ZIP_PATH, 'r') as z:
                step_files = [n for n in sorted(z.namelist()) if n.endswith('.step') and not any(k in n for k in SKIP_KEYWORDS)]

                for name in step_files:
                    clean_name = name.replace('Enclosure - ', '').replace('.step', '').strip()
                    tmp_step = tmp_dir / f"{clean_name}.step"
                    with open(tmp_step, 'wb') as f:
                        f.write(z.read(name))

                    shape = Part.Shape()
                    shape.read(str(tmp_step))
                    tmp_step.unlink()

                    bb = shape.BoundBox
                    dims = sorted([bb.XLength, bb.YLength, bb.ZLength])
                    t_raw = dims[0]
                    t = min(MATERIAL_SPECS.keys(), key=lambda k: abs(k - t_raw))

                    planar_faces = [f for f in shape.Faces if isinstance(f.Surface, Part.Plane)]
                    if not planar_faces:
                        continue
                    planar_faces.sort(key=lambda f: f.Area, reverse=True)
                    face = planar_faces[0]

                    norm = face.normalAt(0, 0)
                    rot = FreeCAD.Rotation(norm, FreeCAD.Vector(0, 0, 1))
                    sh = face.copy()
                    sh.Placement = FreeCAD.Placement(FreeCAD.Vector(0, 0, 0), rot)
                    f_bb = sh.BoundBox
                    sh.Placement = FreeCAD.Placement(FreeCAD.Vector(-f_bb.XMin, -f_bb.YMin, 0), FreeCAD.Rotation()) * sh.Placement

                    idx = len(panels_by_thickness[t])
                    panels_by_thickness[t][idx] = (clean_name, sh)
        else:
            print(f"Error: Neither {PANELS_DIR} nor {ZIP_PATH} found.")
            sys.exit(1)

        print("\n" + "=" * 70)
        print("1. Generating Individual Panel Files (.dxf, .svg, .pdf):")
        print("=" * 70)

        for t, parts in panels_by_thickness.items():
            spec = MATERIAL_SPECS[t]
            target_folder = OUTPUT_DIR / spec['folder']
            target_folder.mkdir(parents=True, exist_ok=True)

            for idx, (clean_name, sh) in parts.items():
                dxf_p = target_folder / f"{clean_name}.dxf"
                svg_p = target_folder / f"{clean_name}.svg"
                pdf_p = target_folder / f"{clean_name}.pdf"
                export_panel_vectors(sh, dxf_p, svg_p, pdf_p)
                bb = sh.BoundBox
                print(f"  [{spec['folder']:24s}] {clean_name:16s} ({bb.XLength:5.1f} x {bb.YLength:5.1f} mm)")

        print("\n" + "=" * 70)
        print("2. Nesting with Sparrow Optimization Engine:")
        print("=" * 70)

        nest_results = []
        for t, parts in panels_by_thickness.items():
            if not parts:
                continue
            spec = MATERIAL_SPECS[t]
            target_folder = OUTPUT_DIR / spec['folder']
            th_str = f"{t:.1f}mm"

            if len(parts) == 1:
                clean_name, sh = list(parts.values())[0]
                placed = [(clean_name, sh.copy())]
            else:
                sparrow_work = tmp_dir / f"sparrow_{th_str}"
                sparrow_work.mkdir(parents=True, exist_ok=True)
                placed = run_sparrow_nest(parts, spec['strip_h'], sparrow_work)

            fw, fh, status = export_nested_sheet(placed, target_folder, th_str, spec['sheet_w'], spec['sheet_h'])
            nest_results.append((spec['label'], f"{fw:.1f} x {fh:.1f} mm", f"{spec['sheet_w']:.0f} x {spec['sheet_h']:.0f} mm", status))

        print("\n" + "=" * 70)
        print("Final Manufacturing Nest Summary:")
        print("=" * 70)
        for label, footprint, sheet_limit, status in nest_results:
            icon = "✅" if status == "FITS" else "❌"
            print(f"  {icon} {label:32s}: Nest Footprint = {footprint:16s} (Sheet Limit: {sheet_limit})")
        print("=" * 70)

        # Update bundle zip
        if BUNDLE_ZIP.exists():
            BUNDLE_ZIP.unlink()
        shutil.make_archive(str(BUNDLE_ZIP.with_suffix('')), 'zip', OUTPUT_DIR)
        print(f"\nUpdated bundle archive: {BUNDLE_ZIP.name}")

    finally:
        if tmp_dir.exists():
            shutil.rmtree(tmp_dir)


if __name__ == "__main__":
    main()
