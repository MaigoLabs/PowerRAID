# PowerRAID Enclosure Laser Cutting Files

This directory contains the production-ready 2D profile cuts exported from the CAD enclosure model (`3d_models/Enclosure.step`), optimized and nested for Engineering Student Machine Shop (ESMS) laser cutting.

## Layer Color Convention (Universal Laser / Trotec Standard)

Every exported file separates operations by CAD layer and stroke color with a **0.05 mm hairline**:

| Layer Name | Stroke Color | Hex Code | Operation Order | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| `CUT_INSIDE` | **Red** | `#FF0000` | **1st (Inside cuts first)** | Screw holes, mounting slots, connector cutouts |
| `CUT_OUTSIDE` | **Black** | `#000000` | **2nd (Outside perimeter)** | Outer boundary of each panel |

---

## Material Groups & Sheet Layouts

All files are organized by material thickness, with both individual panel vectors and full-sheet Sparrow-nested production layouts:

### 1. [1.5mm Extruded Acrylic](1.5mm_Extruded_Acrylic)
- **Stock Sheet Size:** $355.6 \times 279.4\text{ mm}$ ($14'' \times 11''$)
- **Nested Footprint:** $300.0 \times 200.0\text{ mm}$ (Fits within stock)
- **Files:**
  - `Bottom Padding.dxf`, `Bottom Padding.svg`, `Bottom Padding.pdf`
  - `1.5mm_Full_Sheet_Nested.dxf`, `1.5mm_Full_Sheet_Nested.svg`, `1.5mm_Full_Sheet_Nested.pdf`

### 2. [3.0mm Cast Acrylic](3.0mm_Cast_Acrylic)
- **Stock Sheet Size:** $533.4 \times 279.4\text{ mm}$ ($21'' \times 11''$)
- **Safe Machine Strip Height:** $245.0\text{ mm}$
- **Nested Footprint:** $413.9 \times 250.9\text{ mm}$ (Fits within stock)
- **Contains:** `Front`, `Middle 1`, `Middle 2`, `Side 1`, `Side 2`
- **Files:**
  - Individual `.dxf`, `.svg`, and `.pdf` files for each panel
  - `3.0mm_Full_Sheet_Nested.dxf`, `3.0mm_Full_Sheet_Nested.svg`, `3.0mm_Full_Sheet_Nested.pdf`

### 3. [4.5mm Cast Acrylic](4.5mm_Cast_Acrylic)
- **Stock Sheet Size:** $660.4 \times 406.4\text{ mm}$ ($26'' \times 16''$)
- **Safe Machine Strip Height:** $390.0\text{ mm}$
- **Nested Footprint:** $582.1 \times 386.9\text{ mm}$ (Fits within stock)
- **Contains:** `Bottom`, `Top`, `Stick B1`, `Stick B2`, `Stick T1`, `Stick T2`
- **Files:**
  - Individual `.dxf`, `.svg`, and `.pdf` files for each panel
  - `4.5mm_Full_Sheet_Nested.dxf`, `4.5mm_Full_Sheet_Nested.svg`, `4.5mm_Full_Sheet_Nested.pdf`

---

## Automated Regeneration

To regenerate all profiles and nesting layouts from CAD:
```bash
python3 scripts/prepare_laser_cut_panels.py
```
This runs OpenCASCADE contour extraction, solves packing via Sparrow (`sparrow`), validates zero geometric overlap, and bundles `PowerRAID_Laser_Cut_Files.zip`.
