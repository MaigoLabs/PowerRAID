# PowerRAID V2 KiCad Source Files

KiCad 10.0 schematic and PCB layout source files for the PowerRAID V2 managed backplane.

Licensed under CERN-OHL-P-2.0.
