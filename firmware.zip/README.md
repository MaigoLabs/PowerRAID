# PowerRAID Pre-Compiled Firmware Release (v0.8.3)

This release archive contains compiled firmware binaries for the ESP32-S3-WROOM-1 module:
- `bootloader.bin`: Second-stage bootloader (flashed at offset 0x0)
- `partitions.bin`: Partition table (flashed at offset 0x8000)
- `firmware.bin`: PowerRAID application image with web API and embedded pramon UI (flashed at offset 0x10000)

## Flashing Instructions

Connect the PowerRAID backplane via USB-C while holding `BOOT1` button, then flash using esptool:

```sh
esptool.py --chip esp32s3 -p /dev/ttyACM0 -b 921600 write_flash \
  0x0 bootloader.bin 0x8000 partitions.bin 0x10000 firmware.bin
```

Note: If an OTA data partition (`boot_app0.bin`) is desired at offset 0xe000, it can be obtained from the standard ESP32 Arduino framework (`tools/partitions/boot_app0.bin`). Initial flashing directly with the three binaries above will boot successfully.

Licensed under Apache-2.0.
