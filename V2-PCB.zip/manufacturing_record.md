# PowerRAID V2 PCB Fabrication and SMT Assembly Specifications

This document details the fabrication options, PCB stackup, automated SMT assembly configuration, and manual assembly notes for the **PowerRAID V2** power backplane.

---

## 1. PCB Fabrication Parameters (JLCPCB)

The PCB design files are optimized for JLCPCB's 4-layer standard capability:

| Parameter Category | Specification | Selected Option | Engineering Justification |
| :--- | :--- | :--- | :--- |
| **Basic Dimensions** | Board Outline | 268.0 mm × 67.0 mm | Sized for 3× Lite-On server PSUs + 12× EPS ports |
| | Layer Count | 4 Layers | Uninterrupted 12V/GND power planes + internal signal routing |
| | Base Material | FR-4 Standard (TG135) | Standard thermal threshold |
| | Finished Thickness | 1.6 mm | Structural rigidity for card-edge insertion forces |
| **Copper & Stackup** | Outer Copper Weight | 1 oz (0.035 mm) | Standard outer foil, supplemented by SMT copper busbars |
| | Inner Copper Weight | 0.5 oz (0.0175 mm) | Standard inner layer foil |
| | Layer Stackup | JLC04161H-7628 | Controlled impedance profile for high-speed ESP32 & I2C lines |
| **Solder Mask & Finish** | Mask Color | Green | High-yield standard solder mask |
| | Silkscreen Color | White | High contrast component labeling |
| | Surface Finish | Leaded HASL | Excellent solder wettability for hand-soldering through-hole ports |
| | Via Treatment | Tented / Plugged with Solder Mask | Prevents solder wicking into thermal vias under high-current pads |
| **Manufacturing Tolerances** | Min Hole / Ring | 0.3 mm drill / 0.45 mm annular ring | Standard mechanical clearance |
| | Board Routing | Standard ±0.2 mm CNC routing | Matches mechanical enclosure panel tolerances |
| | Electrical Testing | 100% AOI + Flying Probe Test | Guaranteed trace continuity and isolation |
| **SMT Assembly** | Assembly Type | Single-side SMT (Top Layer) | All SMT components positioned on top layer for cost efficiency |

---

## 2. Component Assembly & Sourcing Strategy

To balance low-volume prototype manufacturing cost against assembly difficulty, components are categorized into automated SMT placement, customer consignment, and manual hand soldering:

### 2.1 Factory SMT Placement (Automated Pick-and-Place)
Critical fine-pitch ICs, surface-mount passives, tactile buttons, and heavy copper busbars are soldered via automated reflow:
- **ICs & Supervisors:** `U6` (TI TPS386000 quad supervisor, QFN-20), `U7` (TI TPS56628 12V→5VSB buck, SOIC-8 EP), `U2` (AMS1117-3.3 LDO, SOT-223).
- **Copper Busbars:** `COP1`–`COP14` (SMT red copper busbars 35×8×1 mm, LCSC `C18548299`) reflow-soldered to provide low-resistance conduction paths for 150A+ currents.
- **Passives & Buttons:** 0402/0603/0805 resistors and ceramic MLCCs, tactile switches `BOOT1, EN1` (`C720477`), Schottky diode `D1` (`1N5819WS`), and tantalum capacitor `C201` (10µF 16V Case A).

### 2.2 Customer Consignment (Optional / SMT)
- `USB1`: Type-C 16-pin mid-mount receptacle (LCSC `C2765186`).
- `U4, U5`: Huawei NAE12S20-C 20A DC-DC buck modules (12V→5V and 12V→3.3V).

### 2.3 Hand-Soldered Components (Do Not Place / DNP)
Components intentionally excluded from factory SMT to eliminate extended library feeder fees or because they are through-hole connectors:
1. **Through-Hole Power Connectors:**
   - `CPU1`–`CPU12`: 12× 8-pin EPS-12V Mini-Fit Jr. headers (4.20 mm pitch).
   - `J1`: 1× ATX 24-pin vertical receptacle.
   - `CN1`: 1× 4-pin Molex (LP4) peripheral header (5.08 mm pitch).
   - `PSU1`–`PSU3`: 3× 64-pin card-edge sockets (WingTAT `ER64BGFBK`).
2. **Controller & Level Shifter:**
   - `ESP32`: ESP32-S3-WROOM-1 module (castellated SMD package, hand-soldered or hot-air rework).
   - `U1`: TI TXS0102DCUR I2C level shifter (VSSOP-8).
3. **Bottom-Side Status LEDs & Resistors:**
   - `LED1`–`LED3` (Yellow 0603), `LED_PWR1` (Green 0603), `LED_FAULT1` (Red 0603), and current-limiting resistors `R5`–`R9` (330Ω 0603).
4. **Through-Hole / Manual SMD Passives:**
   - `L701`: 3.3µH 16.15A SMD shielded power inductor (10×10 mm).
   - `C401, C501`: 100µF 16V SMD solid polymer capacitors (6.3×5.9 mm cans).
   - Precision feedback resistors (`R403`: 1.69kΩ, `R504`: 5.76kΩ, `R506`: 432Ω, `R703`: 121kΩ).
   - High-capacitance 1206 MLCC capacitors (`C1`, `C402`–`C404`, `C411`–`C415`, `C502`–`C504`, `C511`–`C515`, `C701`, `C702`, `C707`, `C708`).

---

## 3. Post-Fabrication Bring-Up & Inspection Checklist

1. **Visual & Multimeter Check:**
   - Inspect copper busbar solder joints (`COP1`–`COP14`) for proper solder fill and void-free bonding.
   - Verify that there is no short circuit between `+12V` and `GND` across the busbars.
   - Verify open circuit between `5VSB` and `GND`, `5V` and `GND`, and `3.3V` and `GND`.
2. **EPS Connector Polarity Verification:**
   - **CRITICAL:** Verify the pinout of your modular EPS-to-PCIe cables with a multimeter before installing connectors.
   - On the PowerRAID backplane, the latch clip side of each EPS connector is `GND` and the opposite side is `+12V`.
3. **Initial Standby Bring-Up:**
   - Insert a single server PSU into Slot 1 and connect AC power without asserting `PSON#`.
   - Measure `12VSB` (12.0V), `5VSB` output of `U7` (5.0V ±2%), and `3.3VSB` output of `U2` (3.3V ±2%).
   - Verify that the ESP32-S3 boots and power LED illuminates.
