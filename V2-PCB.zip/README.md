# PowerRAID V2 PCB Production Files

This archive contains the complete production package for the PowerRAID V2 backplane:
- `PowerRAID-Gerbers.zip`: Gerber and NC drill files for JLCPCB 4-layer FR-4 manufacturing.
- `bom.csv`: Bill of materials for JLCPCB SMT automated assembly.
- `positions.csv`: Pick-and-place component coordinates (CPL).
- `manufacturing_record.md`: PCB fabrication specifications and JLCPCB ordering parameters.
- `JLCSMT_BOM_Record.xls`: Audit of factory-placed SMT components vs. hand-soldered parts.

Licensed under CERN-OHL-P-2.0.
